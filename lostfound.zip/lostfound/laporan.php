<?php 
require_once 'config/db.php';
// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    // Arahkan ke login jika belum
    header('Location: login.php');
    exit();
}

// Inisialisasi variabel formulir, diisi dengan nilai default
$default_tipe = '';
$default_judul = '';
$default_deskripsi = '';
$default_lokasi = '';
$success_message = null;

// Cek apakah ada data laporan yang disalin dari copy.php
if (isset($_SESSION['copied_report'])) {
    $copied_report = $_SESSION['copied_report'];
    
    // Isi variabel formulir dengan data yang disalin
    $default_tipe = $copied_report['tipe_laporan'] ?? '';
    $default_judul = $copied_report['judul_item'] ?? '';
    $default_deskripsi = $copied_report['deskripsi'] ?? '';
    $default_lokasi = $copied_report['lokasi_kejadian'] ?? '';

    // Ambil pesan sukses yang mungkin dibawa dari copy.php
    if (isset($_SESSION['success_report'])) {
        $success_message = $_SESSION['success_report'];
        unset($_SESSION['success_report']); // Hapus setelah dibaca
    }
    
    // Hapus data salinan dari sesi setelah selesai digunakan
    unset($_SESSION['copied_report']);
}

// Cek pesan sukses dari proses tambah laporan (jika ada)
if (isset($_SESSION['success_tambah'])) {
    $success_message = $_SESSION['success_tambah'];
    unset($_SESSION['success_tambah']);
}

// Cek pesan error dari proses tambah laporan (jika ada)
$error_message = null;
if (isset($_SESSION['error_tambah'])) {
    $error_message = $_SESSION['error_tambah'];
    unset($_SESSION['error_tambah']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Laporan - Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; background-color: #f7f9fb; } </style>
</head>
<body class="min-h-screen">
    
    <!-- Navbar (Sama dengan index.php, bisa diinclude) -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <a href="index.php" class="text-xl font-bold text-indigo-600">Lost & Found Kampus</a>
                <a href="index.php" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium transition duration-150">Kembali ke Beranda</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-3xl mx-auto p-6 lg:p-8 mt-10">
        <div class="bg-white p-8 md:p-10 rounded-xl shadow-2xl border border-gray-100">
            <h1 class="text-3xl font-extrabold text-gray-900 mb-6 text-center">Formulir Laporan Baru</h1>
            <p class="text-center text-gray-600 mb-8">Anda melaporkan Kehilangan atau Penemuan?</p>

            <!-- Pesan Sukses -->
            <?php if ($success_message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo htmlspecialchars($success_message); ?></span>
                </div>
            <?php endif; ?>

            <!-- Pesan Error -->
            <?php if ($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo htmlspecialchars($error_message); ?></span>
                </div>
            <?php endif; ?>

            <form action="proses/tambah_laporan.php" method="POST" class="space-y-6" enctype="multipart/form-data">
                
                <div>
                    <label for="tipe" class="block text-sm font-medium text-gray-700">Tipe Laporan</label>
                    <select id="tipe" name="tipe_laporan" required class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <option value="">-- Pilih Tipe --</option>
                        <option value="Hilang" <?php echo ($default_tipe === 'Hilang') ? 'selected' : ''; ?>>Barang Hilang</option>
                        <option value="Ditemukan" <?php echo ($default_tipe === 'Ditemukan') ? 'selected' : ''; ?>>Barang Ditemukan</option>
                    </select>
                </div>

                <div>
                    <label for="judul" class="block text-sm font-medium text-gray-700">Judul Item</label>
                    <input id="judul" name="judul_item" type="text" required 
                           value="<?php echo htmlspecialchars($default_judul); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="Contoh: Dompet Kulit Cokelat">
                </div>

                <div>
                    <label for="deskripsi" class="block text-sm font-medium text-gray-700">Deskripsi Detail</label>
                    <textarea id="deskripsi" name="deskripsi" rows="4" required 
                              class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="Jelaskan detail barang, ciri-ciri, dan isinya (jika ada)."><?php echo htmlspecialchars($default_deskripsi); ?></textarea>
                </div>
                
                <div>
                    <label for="lokasi" class="block text-sm font-medium text-gray-700">Lokasi Kejadian</label>
                    <input id="lokasi" name="lokasi_kejadian" type="text" required 
                           value="<?php echo htmlspecialchars($default_lokasi); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="Contoh: Depan Gedung Rektorat">
                </div>

                <div>
                    <label for="gambar" class="block text-sm font-medium text-gray-700">Unggah Gambar (Opsional)</label>
                    <input id="gambar" name="gambar_item" type="file" accept="image/*" class="mt-1 block w-full text-sm text-gray-500
                        file:mr-4 file:py-2 file:px-4
                        file:rounded-full file:border-0
                        file:text-sm file:font-semibold
                        file:bg-indigo-50 file:text-indigo-700
                        hover:file:bg-indigo-100">
                </div>

                <div>
                    <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150">
                        Kirim Laporan
                    </button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>