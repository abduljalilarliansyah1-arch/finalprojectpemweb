<?php
/**
 * proses/logout.php
 * Menghapus semua data sesi dan mengarahkan pengguna ke halaman login.
 */

// Pastikan sesi sudah dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Hapus semua variabel sesi
$_SESSION = array();

// Jika ingin menghapus cookie sesi, hapus juga cookie-nya.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Hancurkan sesi
session_destroy();

// Redirect ke halaman utama (index.php) atau login.php
header('Location: ../index.php');
exit();
?>