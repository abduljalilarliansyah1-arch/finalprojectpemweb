<?php
// my_reports.php - Dashboard Laporan User
// Memulai sesi dan menyertakan konfigurasi DB
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/db.php';

// Memastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Pengguna';
$reports = [];
$error_fetch = null;

try {
    // UPDATE QUERY: Kita tambahkan 'gambar_url' dan 'deskripsi' agar bisa tampil di Card
    $sql = "
        SELECT report_id, tipe_laporan, judul_item, deskripsi, created_at, status, gambar_url
        FROM reports 
        WHERE user_id = :user_id
        ORDER BY created_at DESC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':user_id' => $user_id]);
    $reports = $stmt->fetchAll();

} catch (PDOException $e) {
    $error_fetch = "Gagal mengambil data laporan: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Saya - Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f7f9fb; }
    </style>
</head>
<body class="flex flex-col min-h-screen">

    <nav class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-indigo-600 flex items-center gap-2">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        Lost & Found
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-gray-700 hidden sm:block">Halo, <strong><?php echo htmlspecialchars($username); ?></strong></span>
                    <a href="index.php" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Beranda</a>
                    <a href="proses/logout.php" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-150">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Laporan Saya</h1>
                    <p class="mt-1 text-gray-500">Kelola riwayat laporan kehilangan atau penemuan barang Anda.</p>
                </div>
                <a href="laporan.php" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition">
                    <svg class="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    Buat Laporan Baru
                </a>
            </div>
        </div>
    </div>

    <div class="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">

        <?php if ($error_fetch): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                <p><?php echo htmlspecialchars($error_fetch); ?></p>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_report'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded shadow-sm">
                <?php echo $_SESSION['error_report']; unset($_SESSION['error_report']); ?>
            </div>
        <?php endif; ?>

        <?php if (count($reports) === 0): ?>
            <div class="text-center py-20 bg-white rounded-xl shadow-sm border border-gray-100">
                <svg class="mx-auto h-16 w-16 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
                <h3 class="mt-2 text-lg font-medium text-gray-900">Belum ada laporan</h3>
                <p class="mt-1 text-gray-500">Mulai laporkan barang hilang atau ditemukan sekarang.</p>
                <div class="mt-6">
                    <a href="laporan.php" class="text-indigo-600 hover:text-indigo-500 font-medium">Buat laporan pertama Anda &rarr;</a>
                </div>
            </div>
        <?php else: ?>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($reports as $report): ?>
                    <div class="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden border border-gray-200 flex flex-col">
                        
                        <div class="px-5 py-3 bg-gray-50 border-b border-gray-100 flex justify-between items-center">
                            <span class="text-xs text-gray-500 font-medium">
                                <?php echo date('d M Y', strtotime($report['created_at'])); ?>
                            </span>
                            <?php if ($report['status'] == 'Selesai'): ?>
                                <span class="px-2 py-1 bg-green-100 text-green-800 text-xs font-bold rounded-full">Selesai</span>
                            <?php else: ?>
                                <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-bold rounded-full">Terbuka</span>
                            <?php endif; ?>
                        </div>

                        <div class="p-5 flex-1 flex flex-row gap-4">
                            <div class="w-20 h-20 flex-shrink-0 bg-gray-200 rounded-lg overflow-hidden">
                                <?php if (!empty($report['gambar_url']) && file_exists($report['gambar_url'])): ?>
                                    <img src="<?php echo htmlspecialchars($report['gambar_url']); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <div class="w-full h-full flex items-center justify-center text-gray-400">
                                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="flex-1">
                                <h3 class="text-lg font-bold text-gray-900 line-clamp-1 mb-1" title="<?php echo htmlspecialchars($report['judul_item']); ?>">
                                    <?php echo htmlspecialchars($report['judul_item']); ?>
                                </h3>
                                <p class="text-sm text-gray-600 line-clamp-2 mb-2">
                                    <?php echo htmlspecialchars($report['deskripsi']); ?>
                                </p>
                                <span class="inline-block text-xs font-semibold px-2 py-0.5 rounded border 
                                    <?php echo ($report['tipe_laporan'] == 'Kehilangan' || $report['tipe_laporan'] == 'Hilang') ? 'border-red-200 text-red-600 bg-red-50' : 'border-teal-200 text-teal-600 bg-teal-50'; ?>">
                                    <?php echo htmlspecialchars($report['tipe_laporan']); ?>
                                </span>
                            </div>
                        </div>

                        <div class="px-5 py-4 bg-gray-50 border-t border-gray-100 flex justify-between items-center gap-2">
                            
                            <a href="edit_laporan.php?id=<?php echo $report['report_id']; ?>" class="flex-1 text-center py-2 px-3 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-indigo-600 transition shadow-sm">
                                Edit
                            </a>

                            <a href="copy.php?id=<?php echo $report['report_id']; ?>" class="flex-1 text-center py-2 px-3 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-green-600 transition shadow-sm" title="Buat salinan baru">
                                <span class="flex justify-center items-center gap-1">
                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"/></svg>
                                    Copy
                                </span>
                            </a>

                            <a href="proses/hapus_laporan.php?id=<?php echo $report['report_id']; ?>" onclick="return confirm('Yakin ingin menghapus laporan ini secara permanen?');" class="flex-none py-2 px-3 bg-white border border-red-200 rounded-lg text-red-600 hover:bg-red-50 hover:border-red-300 transition shadow-sm" title="Hapus Laporan">
                                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                            </a>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>

    <footer class="bg-gray-800 text-white mt-auto py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p>&copy; <?php echo date('Y'); ?> Lost & Found Kampus</p>
        </div>
    </footer>

</body>
</html>