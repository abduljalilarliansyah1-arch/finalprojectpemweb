<?php
// detail.php - Halaman Detail Laporan
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/db.php';

// Cek User Login (Opsional: Tamu bisa lihat detail, tapi navbar beda)
$is_logged_in = isset($_SESSION['user_id']);
$current_user_id = $is_logged_in ? $_SESSION['user_id'] : null;
$username = $is_logged_in ? $_SESSION['username'] : 'Tamu';

$report_id = $_GET['id'] ?? null;
$report = null;
$error_message = null;

// 1. Ambil Data Detail dari Database
if ($report_id) {
    try {
        // Kita join ke tabel users biar tau siapa pelapornya
        $sql = "
            SELECT r.*, u.nama AS nama_pelapor, u.nim, u.email 
            FROM reports r
            JOIN users u ON r.user_id = u.user_id
            WHERE r.report_id = :id
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $report_id]);
        $report = $stmt->fetch();

        if (!$report) {
            $error_message = "Laporan tidak ditemukan.";
        }
    } catch (PDOException $e) {
        $error_message = "Terjadi kesalahan: " . $e->getMessage();
    }
} else {
    $error_message = "ID Laporan tidak valid.";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Laporan - Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; background-color: #f7f9fb; } </style>
</head>
<body class="flex flex-col min-h-screen">

    <nav class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-indigo-600 flex items-center gap-2">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        Lost & Found
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <?php if ($is_logged_in): ?>
                        <a href="my_reports.php" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Laporan Saya</a>
                        <a href="proses/logout.php" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-150">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Masuk</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="flex-grow max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">

        <div class="mb-6">
            <a href="index.php" class="text-indigo-600 hover:text-indigo-800 flex items-center gap-1 text-sm font-medium">
                &larr; Kembali ke Beranda
            </a>
        </div>

        <?php if ($error_message): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-6 rounded-lg text-center">
                <p class="text-lg font-semibold"><?php echo htmlspecialchars($error_message); ?></p>
            </div>
        <?php elseif ($report): ?>

            <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
                <div class="md:flex">
                    
                    <div class="md:w-1/2 bg-gray-100 relative min-h-[300px] md:min-h-full flex items-center justify-center group">
                        <?php if (!empty($report['gambar_url']) && file_exists($report['gambar_url'])): ?>
                            <img src="<?php echo htmlspecialchars($report['gambar_url']); ?>" alt="Gambar Barang" class="w-full h-full object-cover max-h-[500px]">
                            <a href="<?php echo htmlspecialchars($report['gambar_url']); ?>" target="_blank" class="absolute bottom-4 right-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-xs hover:bg-opacity-70 transition opacity-0 group-hover:opacity-100">
                                Lihat Fullsize
                            </a>
                        <?php else: ?>
                            <div class="flex flex-col items-center text-gray-400 p-10">
                                <svg class="w-20 h-20 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                <span class="text-sm">Tidak ada gambar</span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="absolute top-4 left-4">
                            <?php if ($report['tipe_laporan'] == 'Kehilangan' || $report['tipe_laporan'] == 'Hilang'): ?>
                                <span class="bg-red-600 text-white text-sm font-bold px-4 py-2 rounded-full shadow-lg">Hilang</span>
                            <?php else: ?>
                                <span class="bg-teal-600 text-white text-sm font-bold px-4 py-2 rounded-full shadow-lg">Ditemukan</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="md:w-1/2 p-8 flex flex-col">
                        
                        <div class="border-b border-gray-100 pb-4 mb-4">
                            <h1 class="text-3xl font-extrabold text-gray-900 mb-2"><?php echo htmlspecialchars($report['judul_item']); ?></h1>
                            <div class="flex items-center text-sm text-gray-500 gap-4">
                                <span class="flex items-center gap-1">
                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                    <?php echo date('d F Y', strtotime($report['created_at'])); ?>
                                </span>
                                <span class="flex items-center gap-1">
                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                    <?php echo htmlspecialchars($report['nama_pelapor']); ?>
                                </span>
                            </div>
                        </div>

                        <div class="space-y-6 flex-grow">
                            <div>
                                <h3 class="text-sm font-semibold text-gray-400 uppercase tracking-wider">Lokasi Kejadian</h3>
                                <p class="text-gray-800 font-medium mt-1 flex items-start gap-2">
                                    <svg class="w-5 h-5 text-indigo-500 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                    <?php echo htmlspecialchars($report['lokasi_kejadian']); ?>
                                </p>
                            </div>

                            <div>
                                <h3 class="text-sm font-semibold text-gray-400 uppercase tracking-wider">Deskripsi Barang</h3>
                                <p class="text-gray-600 mt-2 leading-relaxed whitespace-pre-line">
                                    <?php echo htmlspecialchars($report['deskripsi']); ?>
                                </p>
                            </div>

                            <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                                <span class="text-sm font-semibold text-gray-500">Status Saat Ini:</span>
                                <?php if ($report['status'] == 'Selesai'): ?>
                                    <span class="ml-2 text-green-700 font-bold flex items-center gap-1">
                                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
                                        SUDAH DISELESAIKAN
                                    </span>
                                <?php else: ?>
                                    <span class="ml-2 text-blue-600 font-bold">MASIH MENCARI / BELUM DIAMBIL</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mt-8 pt-6 border-t border-gray-100">
                            
                            <?php if ($current_user_id == $report['user_id']): ?>
                                <p class="text-sm text-gray-500 mb-3 text-center">Ini adalah laporan Anda.</p>
                                <div class="grid grid-cols-2 gap-4">
                                    <a href="edit_laporan.php?id=<?php echo $report['report_id']; ?>" class="flex justify-center items-center px-4 py-3 border border-gray-300 shadow-sm text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition">
                                        Edit Data
                                    </a>
                                    <a href="proses/hapus_laporan.php?id=<?php echo $report['report_id']; ?>" onclick="return confirm('Yakin hapus?');" class="flex justify-center items-center px-4 py-3 border border-transparent text-sm font-medium rounded-lg text-white bg-red-600 hover:bg-red-700 transition">
                                        Hapus
                                    </a>
                                </div>

                            <?php else: ?>
                                <?php if ($report['status'] == 'Terbuka'): ?>
                                    <div class="space-y-3">
                                        <a href="claim.php?id=<?php echo $report['report_id']; ?>" class="w-full flex justify-center items-center px-6 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 hover:shadow-lg transition transform hover:-translate-y-0.5">
                                            <svg class="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                                            <?php echo ($report['tipe_laporan'] == 'Ditemukan') ? 'Saya Pemilik Barang Ini (Klaim)' : 'Saya Menemukan Barang Ini'; ?>
                                        </a>
                                        
                                        </div>
                                <?php else: ?>
                                    <div class="bg-gray-100 text-center p-4 rounded-lg">
                                        <p class="text-gray-500 font-medium">Laporan ini sudah ditutup/selesai.</p>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>

    <footer class="bg-gray-800 text-white mt-auto py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p>&copy; <?php echo date('Y'); ?> Lost & Found Kampus</p>
        </div>
    </footer>

</body>
</html>