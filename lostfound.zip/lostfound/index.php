<?php 
// index.php - Halaman Utama Lost & Found
// Memulai sesi agar variabel $_SESSION dapat dibaca
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/db.php';

// Cek apakah user sudah login
$is_logged_in = isset($_SESSION['user_id']); 
$username = $is_logged_in ? $_SESSION['username'] : 'Tamu';

// --- LOGIC PENCARIAN & FILTER ---
$searchTerm = trim($_GET['search'] ?? '');
$filterType = $_GET['type'] ?? ''; 

// Persiapan query dinamis
$whereClauses = [];
$params = [];

// 1. Logic Filter Tipe (Hilang/Ditemukan)
if (!empty($filterType)) {
    // Kita cek apakah inputnya valid
    if (in_array($filterType, ['Hilang', 'Kehilangan', 'Ditemukan'])) {
        
        // JAGA-JAGA: Kalau di database kamu tulisannya 'Kehilangan', tapi di URL 'Hilang'
        // Kita paksa konversi biar cocok sama database
        if ($filterType == 'Hilang') {
            // Ubah ini jadi 'Hilang' kalau emang di database tulisannya 'Hilang'
            // Tapi biasanya bahasa baku-nya 'Kehilangan'
            $dbValue = 'Kehilangan'; 
            
            // NOTE: Kalau pas difilter kosong, coba ganti baris atas jadi: $dbValue = 'Hilang';
        } else {
            $dbValue = $filterType;
        }

        // Kalau mau aman, kita pakai OR biar kena dua-duanya (Hilang ATAU Kehilangan)
        $whereClauses[] = "(tipe_laporan = :type OR tipe_laporan = 'Hilang' OR tipe_laporan = 'Kehilangan')";
        $params[':type'] = $filterType; // Ini dummy parameter, logic utamanya di string SQL di atas
    }
}

// 2. Logic Search (Judul/Deskripsi/Lokasi)
if (!empty($searchTerm)) {
    $searchWildcard = '%' . $searchTerm . '%';
    $whereClauses[] = "(judul_item LIKE :search_title OR deskripsi LIKE :search_desc OR lokasi_kejadian LIKE :search_loc)";
    $params[':search_title'] = $searchWildcard;
    $params[':search_desc'] = $searchWildcard;
    $params[':search_loc'] = $searchWildcard;
}

// 3. Menyusun Query SQL Akhir
$sql = "SELECT r.*, u.nama AS pelapor_nama 
        FROM reports r 
        JOIN users u ON r.user_id = u.user_id";

if (count($whereClauses) > 0) {
    $sql .= " WHERE " . implode(" AND ", $whereClauses);
}

$sql .= " ORDER BY r.created_at DESC";

// Eksekusi Query
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $reports = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Terjadi kesalahan database: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lost & Found - Kampus</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f7f9fb; }
    </style>
</head>
<body class="flex flex-col min-h-screen">

    <nav class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-indigo-600 flex items-center gap-2">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        Lost & Found
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <?php if ($is_logged_in): ?>
                        <span class="text-gray-700 hidden sm:block">Halo, <strong><?php echo htmlspecialchars($username); ?></strong></span>
                        <a href="my_reports.php" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Laporan Saya</a>
                        <a href="proses/logout.php" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-150">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Masuk</a>
                        <a href="register.php" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-150">Daftar</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="bg-indigo-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl font-extrabold sm:text-5xl">Temukan Barangmu, Bantu Temanmu</h1>
            <p class="mt-4 text-lg text-indigo-100 max-w-2xl mx-auto">Platform pusat informasi barang hilang dan ditemukan di lingkungan kampus. Laporkan kehilangan atau temuan barang dengan mudah.</p>
        </div>
    </div>

    <div class="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="mb-8 bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded shadow-sm" role="alert">
                <p class="font-bold">Berhasil!</p>
                <p><?php echo $_SESSION['success_message']; ?></p>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="mb-8 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded shadow-sm" role="alert">
                <p class="font-bold">Error!</p>
                <p><?php echo $_SESSION['error_message']; ?></p>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <div class="bg-white p-6 rounded-xl shadow-sm mb-8 border border-gray-100">
            <form action="index.php" method="GET" class="flex flex-col sm:flex-row gap-4">
                
                <div class="flex-1 relative">
                    <input type="text" name="search" 
                           value="<?php echo htmlspecialchars($searchTerm); ?>" 
                           placeholder="Cari nama barang, deskripsi, atau lokasi..." 
                           class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition duration-150">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>
                </div>

                <select name="type" onchange="this.form.submit()" class="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 sm:w-1/4 bg-white transition duration-150 cursor-pointer">
                    <option value="" <?php if (empty($filterType)) echo 'selected'; ?>>Semua Kategori</option>
                    <option value="Hilang" <?php if ($filterType === 'Hilang' || $filterType === 'Kehilangan') echo 'selected'; ?>>Barang Hilang</option>
                    <option value="Ditemukan" <?php if ($filterType === 'Ditemukan') echo 'selected'; ?>>Barang Ditemukan</option>
                </select>

                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-150 shadow-md">
                    Cari
                </button>
            </form>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            
            <?php if (count($reports) === 0): ?>
                <div class="col-span-full text-center py-12">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p class="mt-4 text-lg text-gray-500">Belum ada laporan yang sesuai dengan pencarian kamu.</p>
                </div>
            <?php else: ?>
                <?php foreach ($reports as $report): ?>
                    <div class="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden border border-gray-100 flex flex-col">
                        
                        <div class="h-48 bg-gray-200 relative overflow-hidden group">
                            <?php if (!empty($report['gambar_url']) && file_exists($report['gambar_url'])): ?>
                                <img src="<?php echo htmlspecialchars($report['gambar_url']); ?>" alt="<?php echo htmlspecialchars($report['judul_item']); ?>" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500">
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center text-gray-400 bg-gray-100">
                                    <span class="text-sm">No Image</span>
                                </div>
                            <?php endif; ?>
                            
                            <div class="absolute top-0 right-0 m-3">
                                <?php if ($report['tipe_laporan'] == 'Kehilangan' || $report['tipe_laporan'] == 'Hilang'): ?>
                                    <span class="bg-red-100 text-red-800 text-xs font-bold px-3 py-1 rounded-full shadow-sm">Kehilangan</span>
                                <?php else: ?>
                                    <span class="bg-green-100 text-green-800 text-xs font-bold px-3 py-1 rounded-full shadow-sm">Ditemukan</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="p-5 flex-1 flex flex-col">
                            <h2 class="text-xl font-bold text-gray-900 mb-2 line-clamp-1" title="<?php echo htmlspecialchars($report['judul_item']); ?>">
                                <?php echo htmlspecialchars($report['judul_item']); ?>
                            </h2>
                            
                            <p class="text-gray-600 text-sm mb-3 flex items-center">
                                <svg class="w-4 h-4 mr-1 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                <?php echo htmlspecialchars($report['lokasi_kejadian']); ?>
                            </p>
                            
                            <div class="mt-auto pt-4 border-t border-gray-100 flex justify-between items-center">
                                <span class="text-xs text-gray-500">
                                    <?php echo date('d M Y', strtotime($report['created_at'])); ?>
                                </span>
                                <a href="detail.php?id=<?php echo $report['report_id']; ?>" class="text-indigo-600 font-semibold text-sm hover:text-indigo-800 transition duration-150 flex items-center">
                                    Lihat Detail &rarr;
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

        </div>

        <div class="mt-12 text-center">
            <a href="laporan.php" class="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-full shadow-lg text-white bg-indigo-600 hover:bg-indigo-700 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-300 transform hover:-translate-y-1">
                <svg class="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                Laporkan Sesuatu Sekarang!
            </a>
        </div>
    </div>

    <footer class="bg-gray-800 text-white mt-auto py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p class="mb-2">&copy; <?php echo date('Y'); ?> Lost & Found Kampus</p>
            <p class="text-gray-400 text-sm">Project Tugas Besar Pemrograman Web</p>
        </div>
    </footer>

</body>
</html>