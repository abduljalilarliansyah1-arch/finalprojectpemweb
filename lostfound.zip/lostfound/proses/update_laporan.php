<?php
// proses/update_laporan.php
session_start();
require_once '../config/db.php'; // Naik satu folder ke config

// Cek Login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php'); // Naik satu folder ke root
    exit();
}

// Cek Method POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../my_reports.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$report_id = $_POST['report_id'] ?? null;
$tipe_laporan = $_POST['tipe_laporan'] ?? '';
$judul_item = $_POST['judul_item'] ?? '';
$deskripsi = $_POST['deskripsi'] ?? '';
$lokasi_kejadian = $_POST['lokasi_kejadian'] ?? '';
$status = $_POST['status'] ?? 'Terbuka';

// 1. Validasi Dasar
if (!$report_id) {
    $_SESSION['error_report'] = "ID Laporan tidak valid.";
    header("Location: ../my_reports.php");
    exit();
}

// 2. Ambil Gambar Lama dulu (buat jaga-jaga kalau gak upload baru)
try {
    $stmt = $pdo->prepare("SELECT gambar_url FROM reports WHERE report_id = ? AND user_id = ?");
    $stmt->execute([$report_id, $user_id]);
    $old_data = $stmt->fetch();

    if (!$old_data) {
        $_SESSION['error_report'] = "Laporan tidak ditemukan atau bukan milik Anda.";
        header("Location: ../my_reports.php");
        exit();
    }
    
    $final_gambar_url = $old_data['gambar_url']; // Default pake gambar lama

    // 3. Cek apakah ada Upload Gambar Baru
    if (isset($_FILES['gambar_item']) && $_FILES['gambar_item']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['gambar_item']['tmp_name'];
        $file_name = time() . '_' . $_FILES['gambar_item']['name']; // Rename biar unik
        
        // Pastikan folder ada
        $target_dir = "../assets/img/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        if (move_uploaded_file($file_tmp, $target_dir . $file_name)) {
            // Hapus gambar lama jika ada (opsional, biar hemat storage)
            // if (file_exists("../" . $final_gambar_url)) unlink("../" . $final_gambar_url);
            
            $final_gambar_url = "assets/img/" . $file_name; // Simpan path baru
        }
    }

    // 4. Update Database
    $sql = "UPDATE reports SET 
            tipe_laporan = :tipe,
            judul_item = :judul,
            deskripsi = :desk,
            lokasi_kejadian = :lokasi,
            status = :status,
            gambar_url = :gambar
            WHERE report_id = :id AND user_id = :uid";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':tipe' => $tipe_laporan,
        ':judul' => $judul_item,
        ':desk' => $deskripsi,
        ':lokasi' => $lokasi_kejadian,
        ':status' => $status,
        ':gambar' => $final_gambar_url,
        ':id' => $report_id,
        ':uid' => $user_id
    ]);

    // 5. SUKSES! Redirect ke Halaman Laporan Saya
    $_SESSION['success_message'] = "Laporan berhasil diperbarui!";
    header("Location: ../my_reports.php"); // PENTING: Pake ../ buat balik ke root
    exit();

} catch (PDOException $e) {
    $_SESSION['error_report'] = "Gagal update: " . $e->getMessage();
    header("Location: ../edit_laporan.php?id=" . $report_id);
    exit();
}
?>