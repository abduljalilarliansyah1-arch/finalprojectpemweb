<?php
// Memulai sesi dan menyertakan konfigurasi DB
require_once '../config/db.php'; // Path disesuaikan untuk di dalam folder 'proses'

// Memastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php'); // Path disesuaikan
    exit();
}

$user_id = $_SESSION['user_id'];
// Mengambil ID dari URL
$report_id = $_GET['id'] ?? null;
$report_data = null;
$error_message = null;

// Cek apakah ID laporan valid atau disediakan
if (!$report_id || !is_numeric($report_id)) {
    // Menggunakan pesan error yang dilaporkan user
    $error_message = "ID Laporan tidak disediakan."; 
} else {
    try {
        // Query untuk mengambil data laporan berdasarkan ID dan User ID
        // Ini memastikan hanya pemilik laporan yang bisa mengedit
        $sql = "
            SELECT *
            FROM reports 
            WHERE report_id = :report_id AND user_id = :user_id
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':report_id' => $report_id, ':user_id' => $user_id]);
        $report_data = $stmt->fetch();

        if (!$report_data) {
            $error_message = "Laporan tidak ditemukan atau Anda tidak memiliki akses untuk mengedit laporan ini.";
        }

    } catch (PDOException $e) {
        $error_message = "Gagal mengambil data laporan: " . $e->getMessage();
    }
}

// Menangani pesan sukses/error dari proses update
if (isset($_SESSION['success_report'])) {
    $success_message = $_SESSION['success_report'];
    unset($_SESSION['success_report']); 
}
if (isset($_SESSION['error_report'])) {
    $error_message = $_SESSION['error_report'];
    unset($_SESSION['error_report']); 
}

$username = $_SESSION['username'] ?? 'Pengguna';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Laporan ID #<?php echo htmlspecialchars($report_id ?? 'N/A'); ?> - Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; background-color: #f7f9fb; } </style>
</head>
<body class="min-h-screen">
    
    <!-- Navbar -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <a href="../index.php" class="text-xl font-bold text-indigo-600">Lost & Found Kampus</a> <!-- Path disesuaikan -->
                <div class="flex items-center space-x-4">
                    <a href="../my_reports.php" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Kembali ke Laporan Saya</a> <!-- Path disesuaikan -->
                    <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-md text-sm font-medium transition duration-150">Logout</a> <!-- Path disesuaikan (asumsi logout.php ada di 'proses/') -->
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-3xl mx-auto p-6 lg:p-8 mt-10">
        <div class="bg-white p-8 md:p-10 rounded-xl shadow-2xl border border-gray-100">
            <h1 class="text-3xl font-extrabold text-gray-900 mb-6 text-center">Edit Laporan #<?php echo htmlspecialchars($report_id ?? 'N/A'); ?></h1>

            <!-- Pesan Error / Sukses -->
            <?php if (isset($success_message)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo htmlspecialchars($success_message); ?></span>
                </div>
            <?php endif; ?>
            <?php if (isset($error_message)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo htmlspecialchars($error_message); ?></span>
                </div>
            <?php endif; ?>

            <?php if ($report_data && !$error_message): ?>
            <form action="update_laporan.php" method="POST" class="space-y-6" enctype="multipart/form-data"> <!-- Action disesuaikan (asumsi update_laporan.php ada di 'proses/') -->
                <!-- ID Laporan yang disembunyikan -->
                <input type="hidden" name="report_id" value="<?php echo htmlspecialchars($report_data['report_id']); ?>">
                
                <div>
                    <label for="tipe" class="block text-sm font-medium text-gray-700">Tipe Laporan</label>
                    <select id="tipe" name="tipe_laporan" required class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <option value="Hilang" <?php echo ($report_data['tipe_laporan'] === 'Hilang') ? 'selected' : ''; ?>>Barang Hilang</option>
                        <option value="Ditemukan" <?php echo ($report_data['tipe_laporan'] === 'Ditemukan') ? 'selected' : ''; ?>>Barang Ditemukan</option>
                    </select>
                </div>

                <div>
                    <label for="judul" class="block text-sm font-medium text-gray-700">Judul Item</label>
                    <input id="judul" name="judul_item" type="text" required 
                           value="<?php echo htmlspecialchars($report_data['judul_item']); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                </div>

                <div>
                    <label for="deskripsi" class="block text-sm font-medium text-gray-700">Deskripsi Detail</label>
                    <textarea id="deskripsi" name="deskripsi" rows="4" required 
                              class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($report_data['deskripsi']); ?></textarea>
                </div>
                
                <div>
                    <label for="lokasi" class="block text-sm font-medium text-gray-700">Lokasi Kejadian</label>
                    <input id="lokasi" name="lokasi_kejadian" type="text" required 
                           value="<?php echo htmlspecialchars($report_data['lokasi_kejadian']); ?>"
                           class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                </div>

                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700">Status Laporan</label>
                    <select id="status" name="status" required class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <option value="Terbuka" <?php echo ($report_data['status'] === 'Terbuka') ? 'selected' : ''; ?>>Terbuka (Belum ditemukan/dikembalikan)</option>
                        <option value="Selesai" <?php echo ($report_data['status'] === 'Selesai') ? 'selected' : ''; ?>>Selesai (Sudah ditemukan/dikembalikan)</option>
                        <option value="Diambil" <?php echo ($report_data['status'] === 'Diambil') ? 'selected' : ''; ?>>Diambil (Status khusus untuk barang Ditemukan)</option>
                    </select>
                </div>

                <!-- Bagian Gambar Item (Opsional) -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">Gambar Item Saat Ini</label>
                    <?php if ($report_data['gambar_url']): ?>
                        <div class="mt-2">
                            <!-- Path gambar disesuaikan agar bisa diakses dari folder 'proses' -->
                            <img src="../<?php echo htmlspecialchars($report_data['gambar_url']); ?>" alt="Gambar Item" class="w-32 h-32 object-cover rounded-lg border border-gray-300">
                            <p class="text-xs text-gray-500 mt-1">Gambar saat ini. Jika Anda mengunggah gambar baru, gambar ini akan diganti.</p>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 mt-2">Tidak ada gambar yang diunggah sebelumnya.</p>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="gambar" class="block text-sm font-medium text-gray-700">Ganti Gambar (Opsional)</label>
                    <input id="gambar" name="gambar_item" type="file" accept="image/*" class="mt-1 block w-full text-sm text-gray-500
                        file:mr-4 file:py-2 file:px-4
                        file:rounded-full file:border-0
                        file:text-sm file:font-semibold
                        file:bg-indigo-50 file:text-indigo-700
                        hover:file:bg-indigo-100">
                </div>

                <div>
                    <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>