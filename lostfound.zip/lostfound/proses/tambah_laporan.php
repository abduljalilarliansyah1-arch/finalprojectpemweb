<?php
require_once '../config/db.php';

// Pastikan hanya user yang sudah login yang bisa mengakses
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_tambah_laporan'] = 'Anda harus login untuk membuat laporan.';
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$tipe_laporan = $_POST['tipe_laporan'] ?? '';
$judul_item = $_POST['judul_item'] ?? '';
$deskripsi = $_POST['deskripsi'] ?? '';
$lokasi_kejadian = $_POST['lokasi_kejadian'] ?? '';
$gambar_url = null; // Default null

// --- 1. VALIDASI INPUT ---
if (empty($tipe_laporan) || empty($judul_item) || empty($deskripsi) || empty($lokasi_kejadian)) {
    $_SESSION['error_tambah_laporan'] = 'Semua field wajib diisi.';
    header('Location: ../laporan.php');
    exit();
}

// --- 2. PENANGANAN UPLOAD GAMBAR ---
if (isset($_FILES['gambar_item']) && $_FILES['gambar_item']['error'] === UPLOAD_ERR_OK) {
    $file_tmp = $_FILES['gambar_item']['tmp_name'];
    $file_name = $_FILES['gambar_item']['name'];
    $file_size = $_FILES['gambar_item']['size'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    // Validasi tipe file (hanya gambar)
    $allowed_extensions = ['jpg', 'jpeg', 'png'];
    if (!in_array($file_ext, $allowed_extensions)) {
        $_SESSION['error_tambah_laporan'] = 'Hanya file JPG, JPEG, dan PNG yang diizinkan.';
        header('Location: ../laporan.php');
        exit();
    }
    
    // Batas ukuran file (misalnya 2MB)
    if ($file_size > 2097152) { 
        $_SESSION['error_tambah_laporan'] = 'Ukuran file terlalu besar (Maks 2MB).';
        header('Location: ../laporan.php');
        exit();
    }

    // Buat nama unik untuk file
    $new_file_name = uniqid('report_') . '.' . $file_ext;
    $upload_dir = '../assets/img/'; // Pastikan folder ini ada dan writable

    if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
        $gambar_url = 'assets/img/' . $new_file_name; // Path yang disimpan di DB
    } else {
        $_SESSION['error_tambah_laporan'] = 'Gagal memindahkan file yang diunggah.';
        header('Location: ../laporan.php');
        exit();
    }
}

// --- 3. INSERT DATA KE DATABASE MENGGUNAKAN PDO ---
try {
    // Siapkan statement PDO
    $sql = "INSERT INTO reports (user_id, tipe_laporan, judul_item, deskripsi, lokasi_kejadian, gambar_url, status) 
            VALUES (:user_id, :tipe, :judul, :deskripsi, :lokasi, :gambar, 'Terbuka')";
            
    $stmt = $pdo->prepare($sql);
    
    // Bind parameter untuk mencegah SQL Injection
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':tipe', $tipe_laporan);
    $stmt->bindParam(':judul', $judul_item);
    $stmt->bindParam(':deskripsi', $deskripsi);
    $stmt->bindParam(':lokasi', $lokasi_kejadian);
    $stmt->bindParam(':gambar', $gambar_url);
    
    // Eksekusi
    $stmt->execute();
    
    // Redirect ke halaman utama dengan pesan sukses
    $_SESSION['success_message'] = 'Laporan Anda berhasil dibuat dan telah dipublikasikan!';
    header('Location: ../index.php');
    exit();

} catch (PDOException $e) {
    // Penanganan Error Database
    $_SESSION['error_tambah_laporan'] = 'Gagal menyimpan laporan ke database: ' . $e->getMessage();
    // Di lingkungan pengembangan: echo $e->getMessage();
    header('Location: ../laporan.php');
    exit();
}
?>