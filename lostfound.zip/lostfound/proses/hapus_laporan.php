<?php
// Perubahan 1: Gunakan path yang benar untuk koneksi database
require_once '../config/db.php';

// Pastikan session sudah dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Hanya user yang sudah login yang bisa menghapus
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = 'Anda harus login untuk menghapus laporan.';
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$report_id = $_GET['id'] ?? null;

if (!$report_id || !is_numeric($report_id)) {
    $_SESSION['error_message'] = 'ID Laporan tidak valid.';
    header('Location: ../index.php');
    exit();
}

// --- LOGIKA HAPUS MENGGUNAKAN PDO (Delete) ---
try {
    // 1. Cek kepemilikan laporan
    // Penting: Pastikan hanya pemilik laporan yang dapat menghapus
    $sql_check = "SELECT user_id, gambar_url FROM reports WHERE report_id = :report_id";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->bindParam(':report_id', $report_id, PDO::PARAM_INT);
    $stmt_check->execute();
    $report_data = $stmt_check->fetch(PDO::FETCH_ASSOC);

    if (!$report_data) {
        $_SESSION['error_message'] = 'Laporan tidak ditemukan.';
        header('Location: ../index.php');
        exit();
    }

    if ($report_data['user_id'] != $user_id) {
        $_SESSION['error_message'] = 'Anda tidak memiliki izin untuk menghapus laporan ini.';
        header('Location: ../detail.php?id=' . $report_id);
        exit();
    }
    
    // 2. Jika ada gambar, hapus file gambar dari server
    if ($report_data['gambar_url'] && file_exists('../' . $report_data['gambar_url'])) {
        // Path yang disimpan di DB adalah 'assets/img/...'
        // Kita perlu naik satu tingkat direktori untuk mengakses folder assets dari 'proses/'
        unlink('../' . $report_data['gambar_url']);
    }

    // 3. Hapus data laporan dari database
    $sql_delete = "DELETE FROM reports WHERE report_id = :report_id AND user_id = :user_id";
    $stmt_delete = $pdo->prepare($sql_delete);
    $stmt_delete->bindParam(':report_id', $report_id, PDO::PARAM_INT);
    $stmt_delete->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_delete->execute();
    
    // Redirect sukses
    $_SESSION['success_message'] = 'Laporan berhasil dihapus.';
    header('Location: ../index.php');
    exit();

} catch (PDOException $e) {
    // Penanganan Error Database
    $_SESSION['error_message'] = 'Gagal menghapus laporan: ' . $e->getMessage();
    header('Location: ../index.php');
    exit();
}
?>