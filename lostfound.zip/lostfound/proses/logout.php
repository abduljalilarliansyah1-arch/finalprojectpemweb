<?php
// Pastikan sesi dimulai sebelum mencoba mengakses atau menghancurkannya
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Hapus semua variabel sesi
$_SESSION = array();

// Jika ingin menghapus cookie sesi, hapus juga cookie-nya.
// Perhatikan bahwa ini akan menghapus sesi, bukan hanya data sesi!
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Hancurkan sesi
session_destroy();

// Redirect pengguna ke halaman utama (index.php)
header("Location: ../index.php");
exit();
?>