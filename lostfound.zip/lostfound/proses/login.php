<?php
// Pastikan sesi dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Koneksi ke database (naik satu tingkat direktori)
require_once '../config/db.php'; 

// Cek apakah data dikirim melalui metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit();
}

// MENGHILANGKAN SPASI: Tambahkan trim() pada input password untuk mencegah kegagalan verifikasi
$nim = trim($_POST['nim'] ?? '');
$password = trim($_POST['password'] ?? ''); 

// --- 1. VALIDASI INPUT ---
if (empty($nim) || empty($password)) {
    $_SESSION['error_message'] = 'NIM dan Password wajib diisi.';
    header('Location: ../login.php');
    exit();
}

// --- 2. QUERY USER MENGGUNAKAN PDO ---
try {
    // Cari user berdasarkan NIM
    // Mengambil hash password dari kolom 'password' dan memberinya alias 'hashed_password'
    $sql = "SELECT user_id, nama, nim, password AS hashed_password FROM users WHERE nim = :nim";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':nim', $nim);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // --- 3. VERIFIKASI ---
    if ($user) {
        // PENTING: Cek apakah hash yang diambil dari DB terpotong (harus minimal 60 karakter untuk Bcrypt)
        if (strlen($user['hashed_password']) < 60) {
            $_SESSION['error_message'] = 'Gagal Login: Data hash password di database terpotong (Panjang hash saat ini: ' . strlen($user['hashed_password']) . '). Anda HARUS mengubah kolom `password` di tabel `users` menjadi `VARCHAR(255)` atau lebih panjang.';
            header('Location: ../login.php');
            exit();
        }

        // Verifikasi password
        if (password_verify($password, $user['hashed_password'])) {
            
            // Login Berhasil: Set Session
            // PERBAIKAN: Regenerasi ID Sesi untuk memastikan sesi baru bersih dan disimpan
            session_regenerate_id(true); 
            
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['nama']; 
            $_SESSION['nim'] = $user['nim'];
            
            // Log sukses login (untuk debugging)
            error_log("Login SUKSES untuk NIM: " . $user['nim'] . ". User ID: " . $user['user_id']);

            // Redirect ke halaman utama
            header('Location: ../index.php');
            exit();

        } else {
            // Log kegagalan verifikasi
            error_log("Login GAGAL untuk NIM: " . $nim . ". Password verification failed."); 
            // Login Gagal
            $_SESSION['error_message'] = 'NIM atau Password salah.';
            header('Location: ../login.php');
            exit();
        }
    } else {
        // User tidak ditemukan
        $_SESSION['error_message'] = 'NIM atau Password salah.';
        header('Location: ../login.php');
        exit();
    }

} catch (PDOException $e) {
    // Tangani error database.
    error_log("Login Error: " . $e->getMessage()); 
    // Pesan ini yang ditampilkan ke pengguna
    $_SESSION['error_message'] = 'Terjadi kesalahan sistem. Silakan coba lagi.'; 
    header('Location: ../login.php');
    exit();
}
?>