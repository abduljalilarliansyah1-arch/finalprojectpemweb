<?php
require_once '../config/db.php';

// Pastikan session sudah dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Pastikan request method adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../register.php');
    exit();
}

$nama = trim($_POST['nama'] ?? '');
$nim  = trim($_POST['nim'] ?? '');
$password = $_POST['password'] ?? '';
$current_time = date('Y-m-d H:i:s'); // Ambil waktu saat ini

// PERBAIKAN: Kolom 'email' tidak boleh NULL (berdasarkan error 1048).
// Kita buat nilai email yang unik dari NIM.
$email_value = $nim . '@kampus.ac.id'; 

// Validasi input
if (empty($nama) || empty($nim) || empty($password)) {
    $_SESSION['error_register'] = 'Semua field wajib diisi.';
    header('Location: ../register.php');
    exit();
}

// Validasi NIM 
if (!preg_match('/^\d{8,12}$/', $nim)) {
    $_SESSION['error_register'] = 'Format NIM tidak valid. Harus angka 8-12 digit.';
    header('Location: ../register.php');
    exit();
}

// Hash password sebelum disimpan
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

try {
    // Cek apakah NIM sudah terdaftar
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE nim = ?");
    $stmt->execute([$nim]);
    if ($stmt->fetchColumn() > 0) {
        $_SESSION['error_register'] = 'NIM sudah terdaftar. Silakan login.';
        header('Location: ../register.php');
        exit();
    }

    // Insert user baru ke database
    // Semua kolom yang TIDAK NULL sudah dijamin terisi: nama, nim, password, email, created_at
    $stmt = $pdo->prepare("INSERT INTO users (nama, nim, password, email, created_at) 
                           VALUES (:nama, :nim, :pass_hash, :email, :created_at)");
    
    // Bind parameter
    $stmt->bindParam(':nama', $nama);
    $stmt->bindParam(':nim', $nim);
    $stmt->bindParam(':pass_hash', $hashed_password); 
    $stmt->bindParam(':email', $email_value); // Mengirim string unik, bukan NULL
    $stmt->bindParam(':created_at', $current_time); 
    
    $stmt->execute();

    // Registrasi berhasil, langsung login user
    $_SESSION['user_id'] = $pdo->lastInsertId();
    $_SESSION['username'] = $nama;
    $_SESSION['nim'] = $nim;
    
    // Redirect ke halaman utama
    header('Location: ../index.php');
    exit();

} catch (PDOException $e) {
    // Log error detail untuk debugging
    error_log("Registration Error: " . $e->getMessage());
    
    // Menampilkan pesan error detail dari database
    $_SESSION['error_register'] = 'Pendaftaran gagal: ' . $e->getMessage(); 
    
    header('Location: ../register.php');
    exit();
}
?>