<?php
// proses/claim.php
session_start();
require_once '../config/db.php';

// 1. Cek Login & Method POST
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$report_id = $_POST['report_id'] ?? null;
$deskripsi_bukti = trim($_POST['deskripsi_bukti'] ?? '');
$nomor_hp = trim($_POST['nomor_hp'] ?? '');

// 2. Validasi Input
if (empty($report_id) || empty($deskripsi_bukti) || empty($nomor_hp)) {
    // Kalau kosong, balikin ke halaman form
    echo "<script>alert('Mohon lengkapi semua data!'); window.history.back();</script>";
    exit();
}

try {
    // 3. Cek apakah user sudah pernah nge-klaim barang ini sebelumnya? (Anti-Spam)
    $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM claims WHERE report_id = ? AND user_id = ?");
    $stmtCheck->execute([$report_id, $user_id]);
    
    if ($stmtCheck->fetchColumn() > 0) {
        // Kalau udah pernah
        $_SESSION['error_message'] = "Anda sudah pernah mengajukan klaim untuk barang ini. Mohon tunggu respon pelapor.";
        header("Location: ../detail.php?id=" . $report_id);
        exit();
    }

    // 4. Insert Data Klaim ke Database
    $sql = "INSERT INTO claims (report_id, user_id, deskripsi_bukti, nomor_hp, status_klaim) 
            VALUES (:rid, :uid, :desc, :hp, 'Pending')";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':rid' => $report_id,
        ':uid' => $user_id,
        ':desc' => $deskripsi_bukti,
        ':hp'   => $nomor_hp
    ]);

    // 5. Sukses! Redirect balik ke halaman Detail
    $_SESSION['success_message'] = "Pengajuan klaim BERHASIL! Pelapor akan segera menghubungi Anda via WhatsApp jika bukti sesuai.";
    header("Location: ../detail.php?id=" . $report_id);
    exit();

} catch (PDOException $e) {
    die("Gagal memproses klaim: " . $e->getMessage());
}
?>