<?php
// claim.php - Halaman Form Pengajuan Klaim
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/db.php';

// 1. Cek Login (Wajib Login buat klaim biar ketahuan siapa yang minta)
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "Silakan login dulu untuk mengajukan klaim.";
    header('Location: login.php');
    exit();
}

$report_id = $_GET['id'] ?? null;
$user_id = $_SESSION['user_id'];
$report = null;

// 2. Ambil Info Barang yang mau diklaim (Buat ditampilin di atas form)
if ($report_id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM reports WHERE report_id = :id");
        $stmt->execute([':id' => $report_id]);
        $report = $stmt->fetch();

        // Validasi: Kalau barang gak ada, atau malah ngeklaim barang sendiri
        if (!$report) {
            echo "<script>alert('Barang tidak ditemukan!'); window.location='index.php';</script>";
            exit();
        }
        if ($report['user_id'] == $user_id) {
            echo "<script>alert('Anda tidak bisa mengklaim barang yang Anda laporkan sendiri.'); window.location='detail.php?id=$report_id';</script>";
            exit();
        }

    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajukan Klaim - Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; background-color: #f7f9fb; } </style>
</head>
<body class="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8">

    <div class="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Ajukan Klaim Barang
        </h2>
        <p class="mt-2 text-center text-sm text-gray-600">
            Isi formulir di bawah untuk menghubungi pelapor.
        </p>
    </div>

    <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div class="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-gray-100">
            
            <div class="bg-indigo-50 border-l-4 border-indigo-500 p-4 mb-6 rounded-r">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-indigo-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-indigo-700">
                            Anda akan mengklaim: <br>
                            <span class="font-bold"><?php echo htmlspecialchars($report['judul_item']); ?></span>
                        </p>
                    </div>
                </div>
            </div>

            <form class="space-y-6" action="proses/claim.php" method="POST">
                <input type="hidden" name="report_id" value="<?php echo $report['report_id']; ?>">

                <div>
                    <label for="deskripsi_bukti" class="block text-sm font-medium text-gray-700">
                        Bukti Kepemilikan / Detail Barang
                    </label>
                    <div class="mt-1">
                        <textarea id="deskripsi_bukti" name="deskripsi_bukti" rows="4" required 
                                  class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                  placeholder="Jelaskan ciri-ciri khusus barang yang hanya Anda yang tahu (misal: isi dompet, goresan di HP, dll)."></textarea>
                    </div>
                </div>

                <div>
                    <label for="nomor_hp" class="block text-sm font-medium text-gray-700">
                        Nomor WhatsApp yang bisa dihubungi
                    </label>
                    <div class="mt-1">
                        <input id="nomor_hp" name="nomor_hp" type="text" required 
                               class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                               placeholder="08xxxxxxxxxx">
                    </div>
                    <p class="mt-2 text-xs text-gray-500">Pelapor akan menghubungi nomor ini jika verifikasi berhasil.</p>
                </div>

                <div class="flex gap-3">
                    <a href="detail.php?id=<?php echo $report['report_id']; ?>" class="w-1/3 flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
                        Batal
                    </a>
                    <button type="submit" class="w-2/3 flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Kirim Pengajuan
                    </button>
                </div>
            </form>

        </div>
    </div>
</body>
</html>