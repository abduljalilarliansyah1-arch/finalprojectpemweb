<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'config/db.php';

$report_id = $_GET['id'] ?? null;
$user_id = $_SESSION['user_id'];

if (!$report_id) {
    $_SESSION['error_report'] = "ID Laporan tidak valid untuk disalin.";
    header('Location: my_reports.php');
    exit();
}

try {
    // 1. Ambil data laporan yang akan disalin (Pastikan laporan milik pengguna yang login)
    $sql = "
        SELECT judul_item, deskripsi, tipe_laporan, lokasi_kejadian
        FROM reports 
        WHERE report_id = :report_id AND user_id = :user_id
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':report_id' => $report_id, ':user_id' => $user_id]);
    $report = $stmt->fetch();

    if (!$report) {
        $_SESSION['error_report'] = "Laporan tidak ditemukan atau Anda tidak memiliki izin untuk menyalinnya.";
        header('Location: my_reports.php');
        exit();
    }

    // 2. Simpan data ke SESSION untuk dimuat di halaman laporan.php
    $_SESSION['copied_report'] = [
        'judul_item' => $report['judul_item'] . " (COPY)",
        'deskripsi' => $report['deskripsi'],
        'tipe_laporan' => $report['tipe_laporan'],
        'lokasi_kejadian' => $report['lokasi_kejadian'],
    ];
    
    // 3. Redirect ke halaman buat laporan (laporan.php)
    $_SESSION['success_report'] = "Data laporan berhasil disalin ke formulir baru. Silakan ubah dan simpan.";
    header('Location: laporan.php');
    exit();

} catch (PDOException $e) {
    $_SESSION['error_report'] = "Gagal menyalin data laporan: " . $e->getMessage();
    header('Location: my_reports.php');
    exit();
}
?>