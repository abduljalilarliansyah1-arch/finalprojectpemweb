<?php
/**
 * Konfigurasi Koneksi Database (db.php)
 * Menggunakan PDO (PHP Data Objects) untuk koneksi yang aman.
 */

// Ganti nilai-nilai berikut dengan detail database Anda
$host = 'localhost'; // Biasanya localhost
$db   = 'lostfound_kampus'; // Nama database Anda
$user = 'root'; // Username database Anda
$pass = ''; // Password database Anda
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
     // echo "Koneksi database berhasil!"; // Hapus ini setelah pengujian
} catch (\PDOException $e) {
     throw new \PDOException($e->getMessage(), (int)$e->getCode());
     // Dalam mode produksi, tampilkan pesan error generik.
     // exit('Koneksi database gagal. Silakan coba lagi nanti.');
}

// Fungsi untuk memulai sesi dan memastikan sesi sudah berjalan
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>