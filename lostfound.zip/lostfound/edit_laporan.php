<?php
// edit_laporan.php - Halaman Edit Laporan
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'config/db.php';

$report_id = $_GET['id'] ?? null;
$user_id = $_SESSION['user_id'];
$report = null;
$error_message = null;

// Ambil data laporan
if ($report_id) {
    try {
        $sql = "SELECT * FROM reports WHERE report_id = :report_id AND user_id = :user_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':report_id' => $report_id, ':user_id' => $user_id]);
        $report = $stmt->fetch();

        if (!$report) {
            $error_message = "Laporan tidak ditemukan atau Anda tidak punya akses.";
        }
    } catch (PDOException $e) {
        $error_message = "Error DB: " . $e->getMessage();
    }
} else {
    $error_message = "ID Laporan tidak valid.";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Laporan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">

    <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-xl shadow-lg">
        
        <?php if ($error_message): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded">
                <p><?php echo htmlspecialchars($error_message); ?></p>
                <div class="mt-4">
                    <a href="my_reports.php" class="text-indigo-600 hover:text-indigo-500 font-medium">&larr; Kembali ke Dashboard</a>
                </div>
            </div>
        <?php else: ?>

            <div>
                <h2 class="text-3xl font-extrabold text-gray-900 text-center">Edit Laporan</h2>
                <p class="mt-2 text-center text-sm text-gray-600">Perbarui informasi laporan Anda</p>
            </div>

            <form class="mt-8 space-y-6" action="proses/update_laporan.php" method="POST" enctype="multipart/form-data">
                
                <input type="hidden" name="report_id" value="<?php echo $report['report_id']; ?>">

                <div>
                    <label class="block text-sm font-medium text-gray-700">Status Laporan</label>
                    <select name="status" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <option value="Terbuka" <?php echo ($report['status'] == 'Terbuka') ? 'selected' : ''; ?>>Terbuka (Sedang Dicari/Menunggu)</option>
                        <option value="Selesai" <?php echo ($report['status'] == 'Selesai') ? 'selected' : ''; ?>>Selesai (Sudah Ditemukan/Diklaim)</option>
                    </select>
                </div>

                <div>
                    <label for="judul_item" class="block text-sm font-medium text-gray-700">Nama Barang</label>
                    <input id="judul_item" name="judul_item" type="text" required 
                           value="<?php echo htmlspecialchars($report['judul_item']); ?>"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Kategori</label>
                    <select name="tipe_laporan" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <option value="Kehilangan" <?php echo ($report['tipe_laporan'] == 'Kehilangan' || $report['tipe_laporan'] == 'Hilang') ? 'selected' : ''; ?>>Barang Hilang</option>
                        <option value="Ditemukan" <?php echo ($report['tipe_laporan'] == 'Ditemukan') ? 'selected' : ''; ?>>Barang Ditemukan</option>
                    </select>
                </div>

                <div>
                    <label for="deskripsi" class="block text-sm font-medium text-gray-700">Deskripsi</label>
                    <textarea id="deskripsi" name="deskripsi" rows="3" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($report['deskripsi']); ?></textarea>
                </div>

                <div>
                    <label for="lokasi_kejadian" class="block text-sm font-medium text-gray-700">Lokasi</label>
                    <input id="lokasi_kejadian" name="lokasi_kejadian" type="text" required 
                           value="<?php echo htmlspecialchars($report['lokasi_kejadian']); ?>"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Gambar (Biarkan kosong jika tidak diganti)</label>
                    <?php if (!empty($report['gambar_url'])): ?>
                        <div class="mt-2 mb-2">
                            <p class="text-xs text-gray-500">Gambar saat ini:</p>
                            <img src="<?php echo htmlspecialchars($report['gambar_url']); ?>" alt="Current Image" class="h-20 w-auto rounded border border-gray-300 mt-1">
                        </div>
                    <?php endif; ?>
                    <input type="file" name="gambar_item" accept="image/*" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                </div>

                <div class="flex space-x-4">
                    <a href="my_reports.php" class="w-1/2 flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                        Batal
                    </a>
                    <button type="submit" class="w-1/2 flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Simpan
                    </button>
                </div>

            </form>
        <?php endif; ?>
    </div>
</body>
</html>