<?php 
session_start();
// Jika sudah login, redirect ke halaman utama
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}
$error_message = isset($_SESSION['error_register']) ? $_SESSION['error_register'] : '';
unset($_SESSION['error_register']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - Lost & Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; background-color: #f7f9fb; } </style>
</head>
<body class="min-h-screen flex items-center justify-center">

    <div class="w-full max-w-md">
        <div class="bg-white p-8 md:p-10 rounded-xl shadow-2xl border border-gray-100">
            <h2 class="text-3xl font-extrabold text-gray-900 text-center mb-2">Buat Akun Baru</h2>
            <p class="text-center text-gray-600 mb-8">Sudah punya akun? <a href="login.php" class="text-indigo-600 hover:text-indigo-700 font-medium">Login di sini</a></p>
            
            <?php if ($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo htmlspecialchars($error_message); ?></span>
                </div>
            <?php endif; ?>

            <form action="proses/register.php" method="POST" class="space-y-6">
                
                <div>
                    <label for="nama" class="block text-sm font-medium text-gray-700">Nama Lengkap</label>
                    <div class="mt-1">
                        <input id="nama" name="nama" type="text" required class="appearance-none block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="Nama Lengkap Anda">
                    </div>
                </div>

                <div>
                    <label for="nim" class="block text-sm font-medium text-gray-700">NIM</label>
                    <div class="mt-1">
                        <input id="nim" name="nim" type="text" required class="appearance-none block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="Nomor Induk Mahasiswa">
                    </div>
                </div>
                
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                    <div class="mt-1">
                        <input id="password" name="password" type="password" required class="appearance-none block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="Masukkan Password">
                    </div>
                </div>

                <div>
                    <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150">
                        Daftar
                    </button>
                </div>
            </form>
        </div>
    </div>
    
</body>
</html>